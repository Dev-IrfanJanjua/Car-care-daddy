# Car Care Daddy — website & admin prototype

Open `index.html` in Chrome/Edge/Safari. (Best: run `python3 -m http.server` in this folder and visit http://localhost:8000.)

Public pages: index.html (Home) · services.html · gallery.html · about.html · contact.html
Admin: admin/login.html  (any email/password works in the prototype)

How the demo works: all content lives in assets/js/store.js and is saved in your browser (localStorage).
Edit something in /admin and refresh the public pages to see it. Admin > Data & backup > Reset restores the demo.
Nothing in your original project folder was changed.
